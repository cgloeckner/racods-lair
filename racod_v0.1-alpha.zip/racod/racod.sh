#!/bin/bash

export LD_LIBRARY_PATH=$PWD
./racod_game
